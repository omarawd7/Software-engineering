package sw;
import java.util.Scanner;

public class NormalUser extends  User{
	DriverUser dr=new DriverUser();
	notification n=new notification();
	
	int count = 0;	
	
	
	public NormalUser(String username, String name, String password, String mail, String phone) {
		super(username, name, password, mail, phone);
		// TODO Auto-generated constructor stub
	}

	public NormalUser() {
		// TODO Auto-generated constructor stub
	}
	
	public void requestRide() {
		Scanner sc=new Scanner(System.in);
		Ride r = new Ride();
		
		System.out.println("please detect your location right now");
		 r.setSource(sc.next());
		System.out.println("Where to ? ");
		r.setDestination(sc.next());
		n.notifyForOffers(r);	}
	public void givesRate(int x) {
		
		Scanner scan=new Scanner(System.in);
		x=scan.nextInt();
		if(x>0 && x<5) {
			dr.rates[count]=x;
			n.notifyForLatestRideRate(dr);
		}
		else {
			System.out.println("you can't give neither a negative rate nor a rate greater than 5,"
					+ " give a new  rate please  ");
			scan=new Scanner (System.in);
			x=scan.nextInt();
			if(x>0&&x<5)
				{dr.rates[count]=x;
			   n.notifyForLatestRideRate(dr);}
			else 
				System.exit(-1);	
		}
		count++;
	}
	public int[] getRate() {
		return dr.rates;
	}
	
	
	
	
	
	
}
