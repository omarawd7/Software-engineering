package sw;
import java.util.Scanner;

public class DriverUser extends  User {
	
	
	 String[] array =new String[100] ;
	 static favouriteAreas a = new favouriteAreas();
	notification notf=new notification();
	
	
	//favouriteAreas a[]=null;
	int [ ] rates;
	public DriverUser(String username, String name, String password, String mail, String phone) {
		super(username, name, password, mail, phone);
		// TODO Auto-generated constructor stub
	}
	public DriverUser() {
		// TODO Auto-generated constructor stub
	}
	String DriverLiecense;
	 int NationalID;

 public String getDriverLiecense() {
		return DriverLiecense;
	}
	public void setDriverLiecense(String driverLiecense) {
		DriverLiecense = driverLiecense;
	}
	public int getNationalID() {
		return NationalID;
	}
	public void setNationalID(int nationalID) {
		NationalID = nationalID;
	}


/////////////////////////////////////////////////
	//function to add  offer to list of offer
    public void suggestOffer(Ride r) 
	   {
    	Offer f = new Offer();
    	Scanner scan = new Scanner(System.in);
			System.out.println("Enter the value you want to set for the ride ");
			 f.setPrice(scan.nextDouble());
		     int n=0;
		   for(int i=0;i<=n;i++) {
	       r.offers[n]=f;
		   }
		   n++;   
	     
	      
		}

	void addFavouriteAreas() {
		Scanner s1 = new Scanner(System.in);
		
		System.out.println("How many areas do you want to add?");
		int length = s1.nextInt();
		array=new String [length];
		System.out.println("Please select your favourite areas");
		s1 = new Scanner(System.in);
        for (int i = 0; i < length;i++){
            array[i] = s1.nextLine();		
        }
         
        
        System.out.println("Added successfuly!");
        a.setLocations (array);
        
	}
   
   
public String[] listAllRides(Ride r) 
   { int x=0;
      String[] MyFav = new String[x+1] ;
	if(a.getSourceArea()==r.getSource()); 	
	
		 {  
            MyFav[x]=r.getSource();
		     x++;
		   }
	  
	  
	return  MyFav;
	 
   }



public double avgRating(double[] ratings) {
	int noOfRatings=ratings.length;
	double sumArr=0;
	for(int i=0; i<ratings.length;i++)
	{
		sumArr+=ratings[i];
	}
	double avg= sumArr/noOfRatings;
	return avg;
	
	
} 


	void addSourceArea() {
		Scanner s1 = new Scanner(System.in);
		System.out.println("Please select your source area");
		String source = s1.nextLine();
		a.setSourceArea(source);
	}
	public void listMyRatings( ) {
		NormalUser n= new NormalUser() ; 
		System.out.print("Your rates are : ");
		System.out.print(n.getRate());
	}
}
