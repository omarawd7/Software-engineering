package sw;
import java.util.Scanner;
public  class  Validation {
	Scanner sc =new Scanner(System.in);
   public void check(DataBase db,String userName,String password){
  int admin=0;
  int driver=0;
  int normaluser=0;
 
  
   boolean isDriver=false;
   boolean isAdmin=false;
   boolean isUser=false;
   User us;
   for(int i=0;i<db.getUserData().size();i++){//checking if it is a normal  user
       if(db.getUserData().get(i).getUserName().equals(userName) && db.getUserData().get(i).getPassword().equals(password))
       isUser=true;
        normaluser=i;
       break;
   }
   for(int i=0;i<db.getDriverData().size();i++){//checking if it is a driver
    if(db.getDriverData().get(i).getUserName().equals(userName)&& db.getDriverData().get(i).getPassword().equals(password))
       isDriver=true;
    driver=i;
    break;
   }
    for(int i=0;i<db.getAdminData().size();i++){//checking if it is an admin
    if(db.getAdminData().get(i).getUserName().equals(userName) && db.getAdminData().get(i).getPassword().equals(password))
       isAdmin=true;
     admin=i;
    break;
  
   }
    if(isUser==true) 
    	
    {
    	while(true)
    	{
    		NormalUser normal = new NormalUser();
    		Ride r= new Ride();
    		
    	System.out.println("Welcome User!\nplease choose a number\n1-request a ride\n2-rate your latest ride");
    	
    	int num = sc.nextInt();
    	UserMenu:
    	if(num==1) {
    			normal.requestRide();
    			System.out.println("looking for drivers!");
    			
    			
    			
    		   		
    		}
    	else if(num==2) {
    		DriverUser d=new DriverUser();
    		System.out.println("could you please give a rate for the driver ");
    		num=sc.nextInt();
    		normal.givesRate(num);
    		normal.n.notifyForLatestRideRate(d);
    	
    		
    		
    		System.out.println("successfully added a rate ");
    	}
    	else
    		continue;
    	}
    }
     if(isAdmin==true) {
    	us=new admin();
    	((admin) us).AddNewDriver();
 
    }
     if(isDriver==true)
    {
    	 DriverUser d = new DriverUser();
    	 while(true) {
    	 System.out.println("Welcome Driver!\nplease choose a number\n1-Select Your favourite areas"
    	 		+ " and your source \n2-List nearby requests\n3-list my ratings ");
    	int num = sc.nextInt();
    	DriverMenu:
    	if(num == 1 ) {
    				d.addSourceArea();
    				d.addFavouriteAreas();
    			
    	    		
    	}
    	else if (num ==2 ) {
    		Ride r=new Ride();
    		System.out.println("enter the source area or the pick up point for your ride");
    		r.setSource(sc.next());
    		System.out.println("enter the drop or destenation for your ride");
    		r.setDestination(sc.next());
    		d.listAllRides(r);
    		d.notf.notifyForOffers(r);
    	
    		}
    	else if (num == 3 ) {
    		d.listMyRatings();
    		}
    	
    	else 
    		{
    		System.out.println("Please choose a valid number ");
    		continue;
    		
    		}
    	 }
    }
    if (isDriver==false&&isAdmin==false&&isUser==false) {
		 System.out.println("Wrong password or User name");	
		 Login l=new Login();
		 l.validate(db);
    	//return null;
    }
  
    }
public static void main(String[] args) {
	admin ahmed=new admin("admin","admin","0000","ahemd@home","655463");
	NormalUser omar=new NormalUser("omar","omar","54563","omar@home","65512");
	DriverUser mohamed=new DriverUser("mohamed","momo","05464","mohamed@home","482364");
	DataBase db=new DataBase();
	db.addNormalUser(omar);
	db.addDriverUser(mohamed);
	db.addAdmin(ahmed);

}
}
