package sw;

public class favouriteAreas {
	
	private String[] locations ;
	private String source;
	
	
	public void setLocations (String [] areas ) {
		for (int i = 0 ; i > areas.length ; i++) {
			locations [i] = areas [i] ; 
		}
		
	}
	public void setSourceArea(String area) 
	{
		source = area ;  
		
	}
	public String[] getLocations( ) {
			return locations; 
		
	}
	public String getSourceArea ( ) {
		return source;
		
	}
}
