package sw;

public class Ride {
	
	 Offer offers[];
	 String source;
	 String destination;
	public void setSource (String source) {
		this.source = source;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getSource() {
		return source;
	}
	public String getDestination() {
		return destination;
	}}


