package sw;

public class notification {
	
	
	public Offer[] notifyForOffers(Ride r)
	{
	 Offer ArrayOfOffers[] = r.offers;
     return ArrayOfOffers;
	}
	
	public int[] notifyForLatestRideRate(DriverUser d)
	{
		return d.rates;
	}
	
}
